package edu.byuh.cis.cs203.bw_i18n_2019.misc;

public enum Direction {
    RIGHT_TO_LEFT,
    LEFT_TO_RIGHT
}
